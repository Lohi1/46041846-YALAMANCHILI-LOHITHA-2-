package Lab9;
import java.util.function.Function;
public class Lab9Program5 {
	  public Integer factorial(int n) {         // instance method 
          if(n==0   || n==1){
                    return 1;
          }
     return n *   factorial(n-1);
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
        //using   lambda  
        Lab9Program5 cal = new Lab9Program5();
     Function<Integer, Integer> funLambda = (a) ->   cal.factorial(a);
     System.out.println("By   Using lambda expression: "+funLambda.apply(6));

     // bound type
     Function<Integer, Integer> funBoundType = cal::factorial;
     System.out.println("Using   a method References To Instance bound type: "+funBoundType.apply(6));
	}

}