package Lab5;
public class Exercise2 {
public static void main(String args[]) {
Exercise2 le2 = new Exercise2();
try {
System.out.println(le2.validateName("Rachana", "Gattu"));
System.out.println(le2.validateName(" ", " "));
}
catch(InvalidNameException e) {
System.out.println(e);
}
}
public String validateName(String firstName, String lastName) throws InvalidNameException {
if(firstName == " " && lastName == " ") {
throw new InvalidNameException("First name and last name should not be blank");
}
else
System.out.println("Name is valid");
return "Name validation";
}
}