package lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Source{
	public List<Integer> getvalues(HashMap<Integer,Integer> map)
	{
		List<Integer> orderedList=new ArrayList<Integer>();
		for(Map.Entry<Integer, Integer> i :map.entrySet()) {
			orderedList.add(i.getValue());
		}
	Collections.sort(orderedList);
	return orderedList;
	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		String[] elements=input.split(",");
		HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
		for(int i=0;i<elements.length-1;i+=2) {
			map.put(Integer.parseInt(elements[i]),Integer.parseInt(elements[i+1]));
		}
		Source source = new Source();
		List<Integer> result=new ArrayList<Integer>();
		result=source.getvalues(map);
		System.out.println(result);
	}
}